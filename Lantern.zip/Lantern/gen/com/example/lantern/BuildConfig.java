/** Automatically generated file. DO NOT MODIFY */
package com.example.lantern;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}